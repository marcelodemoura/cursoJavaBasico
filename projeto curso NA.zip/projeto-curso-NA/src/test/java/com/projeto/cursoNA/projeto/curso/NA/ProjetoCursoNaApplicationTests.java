package com.projeto.cursoNA.projeto.curso.NA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoCursoNaApplicationTests {

	@Test
	void contextLoads() {
	}

}
