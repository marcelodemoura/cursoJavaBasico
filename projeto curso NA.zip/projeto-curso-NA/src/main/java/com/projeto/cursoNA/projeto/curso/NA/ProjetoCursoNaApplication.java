package com.projeto.cursoNA.projeto.curso.NA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoCursoNaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoCursoNaApplication.class, args);
	}

}
